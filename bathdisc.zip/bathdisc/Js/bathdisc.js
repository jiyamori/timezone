
//  $('.carousel .carousel-inner').each(function() {
// 	var next = $(this).next();
// 	if (!next.length) {
// 		next = $(this).siblings(':first');
// 	}
// 	next.children(':first-child').clone().appendTo($(this));

// 	for (var i = 0; i < 6; i++) {
// 		next = next.next();
// 		if (!next.length) {
// 			next = $(this).siblings(':first');
// 		}

// 		next.children(':first-child').clone().appendTo($(this));
// 	}
// });


// $(function () {
//     $('.carousel-inner ').each(function(){
//       var itemToClone = $(this);
  
//       for (var i=1;i<6;i++) {
//         itemToClone = itemToClone.next();
  
//         // wrap around if at end of item collection
//         if (!itemToClone.length) {
//           itemToClone = $(this).siblings(':first');
//         }
  
//         // grab item, clone, add marker class, add to collection
//         itemToClone.children(':first-child').clone()
//           .addClass("cloneditem-"+(i))
//           .appendTo($(this));
//       }
//     });
//   });
  // $('.slider').slick({
  //   infinite: true,
  //   slidesToShow: 3,
  //   slidesToScroll: 3
  // });

  $(document).ready(function(){
    $('.slick-carousel').slick({
      infinite: true,
      slidesToShow: 6,
      slidesToScroll: 1,
      prevArrow: '<button type="button" class="slick-custom-arrow slick-prev"></button>',
      nextArrow: '<button type="button" class="slick-custom-arrow slick-next"></button>',
      responsive: [
        {
          breakpoint: 992,
          settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
            arrows:false,
          }
        },
        {
          breakpoint: 768,
          settings: {
            slidesToShow: 3,
            slidesToScroll: 1,
            arrows:false,
          }
        },
      ]
    });
  });
  $(document).ready(function(){
    $('#hamburgerIcon').click(function(){
        $('.sidenav').toggleClass('show');
    });
});


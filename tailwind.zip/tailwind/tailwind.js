$(document).ready(function(){
  $('#hamburger').click(function(){
    $('.sidebar').toggleClass('active');
    $('.sidebar-nav').toggleClass('sidebar-active');
    $('.overlay').toggleClass('overlay-active');
  });
  $('.cross').click(function(){
    $('.sidebar').removeClass('active');
    $('.sidebar-nav').removeClass('sidebar-active');
    $('.overlay').removeClass('overlay-active');
  })

  $('.arrow-icon').click(function () {
    $('.sidebar-nav').addClass('sidebar-active');
    $('.fa-circle-chevron-right').addClass('hidden');
    $('.fa-circle-chevron-left').removeClass('hidden');
  });

  $('.arrow-icon-left').click(function () {
    $('.sidebar-nav').removeClass('sidebar-active');
    $('.fa-circle-chevron-left').addClass('hidden');
    $('.fa-circle-chevron-right').removeClass('hidden');
  });

});




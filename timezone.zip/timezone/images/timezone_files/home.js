
$(document).ready(function() {
    $('.navigation-col').click(function() {
        $(this).find('.nav-category').toggleClass('active');
    });

    // Toggle nav-col when clicking on plus
    $('.plus').click(function(event) {
        event.stopPropagation(); 
        $(this).siblings('ul.nav-col').slideToggle();
        $(this).toggleClass('minus'); 
    });

    $('#search-icon-link').click(function(){
        $('.main-menu').toggle();
        $('.input-search').toggle();
        $('.search-icon').toggleClass('cross-icon');
     });
     $('.profile-icon').click(function(){
        $('.account').toggleClass('account-active')
     });

     $(".shopping-icon").click(function (a) {
        $(".offcanvas-cart").toggleClass('offcanvas-active');
        $(".overlay").toggleClass('overlay-active');
        a.stopPropagation();
      });
      $(".offcanvas-cart").click(function (a) {
        a.stopPropagation();
      });
      $('.close-btn').click(function(){
          $('.offcanvas-cart').removeClass('offcanvas-active');
      });
      $(document).click(function () {
        $(".offcanvas-cart").removeClass('offcanvas-active');
        $(".overlay").removeClass('overlay-active');  
      });

      $(window).scroll(function() {
				if ($(window).scrollTop() > 50) {
					$('#scroller').addClass('stuck');
				} else {
					$('#scroller').removeClass('stuck');
				}
    
			});
    
});